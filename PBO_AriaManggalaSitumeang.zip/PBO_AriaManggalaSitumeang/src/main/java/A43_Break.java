/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author User
 */
public class A43_Break {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         int counter = 1;
            while (true){
          System.out.println("Perulangan ke- " + counter);
          counter++;

        if(counter > 10){
            break;
      }
    }

    System.out.println("Perulangan berhenti");
    }
    
}