/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author User
 */
public class A12_KataKunciVar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //var name;
        var name = "Eko Kurniawan Khannedy";

        var age = 30;
        var address = "Indonesia";
    
        System.out.println(name);
        System.out.println(age);
        System.out.println(address);
    }
    
}
