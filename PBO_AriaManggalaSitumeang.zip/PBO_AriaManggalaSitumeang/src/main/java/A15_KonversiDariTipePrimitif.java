/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author User
 */
public class A15_KonversiDariTipePrimitif {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int age = 30;
        
        Integer ageObject = age;
        
        int ageAgain = ageObject;
        
        short shortAge = ageObject.shortValue();
        byte byteAge = ageObject.byteValue();
    }
    
}
