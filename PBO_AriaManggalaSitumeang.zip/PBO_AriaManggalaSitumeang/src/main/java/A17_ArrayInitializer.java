/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author User
 */
public class A17_ArrayInitializer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int [] arrayInt = new int[]{
        10, 90, 80, 67, 28
        };
        
        long [] arrayLong = {
        10, 90, 80, 67, 28
        };
    }
    
}
