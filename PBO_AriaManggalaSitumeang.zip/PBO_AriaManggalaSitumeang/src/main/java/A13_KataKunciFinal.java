/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author User
 */
public class A13_KataKunciFinal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        final String name;
        name = "Eko Kurniawan Khannedy";
        int age = 30;
        String address = "Indonesia";
        
        //name = "Nama Diubah";
    
        System.out.println(name);
        System.out.println(age);
        System.out.println(address);
    }
    
}
