/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author User
 */
public class A19_ArrayDiDalamArray {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String[][] members = {
        {"Eko", "Kurniawan"},
        {"Budi", "Nugraha"},
        {"Joko"}
        };
        
        String[] member1 = members[0];
        System.out.println(member1[0]);
        
        System.out.println(members[1][0]);
        System.out.println(members[2][0]);
    }
    
}
